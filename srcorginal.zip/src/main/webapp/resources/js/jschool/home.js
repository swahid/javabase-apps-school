/*
 * new issue button onlcick popup createissueForm function
 */
function createIssueForm_Popup(){
	$('#createIssueForm').animate({height: "toggle", opacity: "toggle"}, "slow");
}