package org.javabase.mvc;

public class HelloWorld {

}
